<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Tshijuka RDP </title>
    
    <!-- Link Styles -->
    <link rel="stylesheet" href="nav.css"> <!-- Navigation bar styles -->
    <link rel="stylesheet" href="about.css"> <!-- Page-specific styles -->
</head>
<body>
    <!-- Include Navigation Bar -->
    <?php include 'nav.php'; ?>

    <div class="container">
        <div class="hero-section">
            <div class="floating-elements">
                <div class="floating-element"></div>
                <div class="floating-element"></div>
                <div class="floating-element"></div>
            </div>
            <div class="title-wrapper">
                <h1>About Tshijuka RDP <span class="tools-icon">🛠️</span></h1>
            </div>
            <div class="content-wrapper">
                <p class="description">
                    Tshijuka RDP is an app that helps refugees and forcely displaced people to retrieve their academic documents(state diploma and high schools transcripts) from country of origin(Dr.Congo).
                </p>
            </div>
            <footer class="footer">
                <p> Tshijuka RDP</p>
            </footer>
        </div>
    </div>

    <script src="about.js"></script>
</body>
</html>
