<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusFixIt - Sign Up</title>
    <link rel="stylesheet" href="styles.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="nav-logo">
            <a href="#">CampusFixIt</a>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </div>

    <!-- Sign Up Form -->
    <div class="container">
        <h1>Sign Up</h1>
        <form id="signupForm">
            <div class="input-space">
                <input type="text" placeholder="Full Name" name="full_name" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-space">
                <input type="text" placeholder="Contact" name="contact" required>
                <i class='bx bxs-phone'></i>
            </div>
            <div class="input-space">
                <input type="email" placeholder="Email" name="email" required>
                <i class='bx bxs-envelope'></i>
            </div>
            <div class="input-space">
                <input type="password" placeholder="Password" name="password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="input-space">
                <input type="password" placeholder="Confirm Password" name="confirm_password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="input-space">
                <select name="userRole" required>
                    <option value="" disabled selected>Select Role</option>
                    <option value="Regular">Regular</option>
                    <option value="Admin">Admin</option>
                </select>
                <i class='bx bxs-user-check'></i>
            </div>
            <button type="submit" class="login-button">Sign Up</button>
        </form>
        <div class="register">
            <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>

    <script>
        document.getElementById('signupForm').addEventListener('submit', async function (event) {
            event.preventDefault(); // Prevent form from submitting normally

            const formData = new FormData(this); // Collect form data

            try {
                // Send signup data via fetch API
                const response = await fetch('signup_action.php', {
                    method: 'POST',
                    body: formData,
                });

                const result = await response.json(); // Parse JSON response

                if (result.success) {
                    // Display success message and redirect if signup successful
                    alert('Signup successful! Redirecting to login page...');
                    window.location.href = result.redirect;
                } else {
                    // Display error message from response
                    alert(result.message);
                }
            } catch (error) {
                console.error('Signup error:', error);
                alert('An unexpected error occurred. Please try again later.');
            }
        });
    </script>
</body>
</html>
