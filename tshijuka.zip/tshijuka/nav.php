<nav class="navbar">
    <div class="nav-logo">
        <img src="logo.jpg" alt="CampusFixIt Logo" class="logo">
    </div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="progress.php">Track Report Progress</a>
        <a href="login.php">Login</a>
    </div>
</nav>
