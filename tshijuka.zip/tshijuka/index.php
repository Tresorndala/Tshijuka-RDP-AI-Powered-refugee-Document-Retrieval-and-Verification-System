<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusFixIt - Home</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="logo.jpg" alt="CampusFixIt Logo" class="logo">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="reports.php">Recent Documents</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="progress.php">Track Documents reports Progress</a></li>
                <li><a href="submit_reportschool.php">if you are a chool ,use this to upload requested documents</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>

        <div class="content">
            <h1>Welcome to Tshijuka RDP app </h1>
            <p> Retrieve academic document from country of origin</p>
            <div>
                <!-- The "Submit a Report" button always redirects to login.php -->
                <a href="login.php"><button type="button">Submit a document request </button></a>
                <a href="signup.php"><button type="button">Sign Up</button></a>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; Tshijuka RDP</p>
    </footer>
</body>
</html>
